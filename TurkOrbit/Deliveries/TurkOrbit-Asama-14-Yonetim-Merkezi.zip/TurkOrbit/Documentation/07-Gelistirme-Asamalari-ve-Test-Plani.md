# 07 — Geliştirme Aşamaları ve Test Planı

**Kural:** Bir aşama, kabul ölçütlerinin **tamamı** otomatik veya belgelenmiş manuel testle doğrulanmadan "tamamlandı" sayılmaz. Her aşama sonunda rapor + ZIP teslimatı hazırlanır.

## 1. Aşama durumu

| # | Aşama | Durum | Not |
|---|---|---|---|
| 1 | Araştırma ve analiz | 🟡 **Kısmen** | Resmî sayfalara ağ engeli nedeniyle doğrudan erişilemedi; arama özetleriyle yapıldı ([01](01-Arastirma-Raporu.md)). Ağ izni verilirse doğrulanacak. |
| 2 | Teknik mimari | ✅ Tamamlandı | [02](02-Teknik-Mimari.md), [03](03-Platform-Mimarisi.md), [05](05-Yonetim-Merkezi-Plani.md) |
| 3 | Veritabanı ve altyapı | ✅ Tamamlandı | 0001 migration + doğrulanmış taslak; docker-compose, nginx örneği |
| 4 | Kayıt ve giriş | ✅ **Web için tamamlandı** | API + web arayüzü + 72 otomatik test + 18 adımlı API E2E + 11 adımlı tarayıcı E2E. Mobil güvenli depolama Aşama 15'te. |
| 5 | Oyuncu profili | ✅ **Tamamlandı** | Sunucu/şirket seçimi, pilot, cüzdan + defter, seviye/rütbe, başarımlar, açık profil. Rapor: [Aşama 5](DevelopmentNotes/Asama-05-Raporu.md) |
| 6 | Hangar ve ekipman | ✅ **Tamamlandı** | 10 gemi, 36 eşya, envanter + defter, 2 konfigürasyon, yükseltme, tamir, PET, mağaza. Rapor: [Aşama 6](DevelopmentNotes/Asama-06-Raporu.md) |
| 7 | Harita ve oyun motoru | ✅ **Tamamlandı (tek oyunculu)** | Phaser 3.90 sahnesi, 21 harita + 60 geçit + 51 bölge, sunucu hız denetimli konum, geçit geçişi, galaksi haritası, mini harita, joystick, cihaz sınıfına göre ayarlar. Rapor: [Aşama 7](DevelopmentNotes/Asama-07-Raporu.md) |
| 8 | Multiplayer | ✅ **Tamamlandı (hareket katmanı)** | WebSocket oyun sunucusu, oyun bileti, 20 Hz sunucu otoriteli hareket, tahmin/uzlaştırma/enterpolasyon, radar menzili (AOI), tek aktif oturum, yeniden bağlanma, istasyon kuralı. Rapor: [Aşama 8](DevelopmentNotes/Asama-08-Raporu.md) |
| 9 | NPC ve savaş | ✅ **Tamamlandı (Yıldız Kapıları hariç)** | Hedef seçme, lazer/roket, sunucu tarafı hasar, 11 NPC türü (2 kadim), yapay zekâ, ölüm/yeniden doğma, katkıya göre bölünen ödül, kargo kutusu, PvP kuralları. Yıldız Kapıları Aşama 10-11'e, canlı içerik güncelleme Aşama 14'e kaldı. Rapor: [Aşama 9](DevelopmentNotes/Asama-09-Raporu.md) |
| 10 | Görev sistemi | ✅ **Tamamlandı** | 300 görev (120 ana/zincir, 90 günlük, 60 haftalık, 30 etkinlik), olay tabanlı sunucu ilerlemesi, 05:00 TSİ sıfırlama (zaman taklidiyle testli), yeniden çekme, defterli ödül, oyun içi izleyici ve çekmece, anında başarımlar. Maden hedefleri Aşama 11'de eklendi; kapı hedefleri ilgili sistemle gelecek. Rapor: [Aşama 10](DevelopmentNotes/Asama-10-Raporu.md) |
| 11 | Ekonomi | ✅ **Tamamlandı** | 7 kaynak ve 45 bölgede madencilik (gemi ambarı), rafineri/atölyede 12 süreli tarif, 9 sistem açık artırması (emanet, iade, son saniye uzatması), 7 günlük giriş ödülü, 3 mağaza paketi, 18 yeni görev (toplam 318). 50 eşzamanlı satın alma kabul ölçütü testli. Rapor: [Aşama 11](DevelopmentNotes/Asama-11-Raporu.md) |
| 12 | Klan ve sosyal | ✅ **Tamamlandı** | Klan (rütbe yetkileri, başvuru/davet, defterli hazine ve %0–5 NPC Kredi vergisi, diplomasi: ittifak/saldırmazlık/savaş saldırı kuralına bağlı), Redis'te grup (atomik, 8 kişi, konum üyenin iznine göre), 6 sohbet kanalı (hız sınırı, küfür filtresi, engelleme), arkadaşlık, gizlilik, bildirimler (açık artırma dahil), şikâyet kuyruğu. Rapor: [Aşama 12](DevelopmentNotes/Asama-12-Raporu.md) |
| 13 | Forum ve destek | ✅ **Tamamlandı** | Oyun hesabıyla ortak forum (6 bölüm, alıntı, beğeni, takip, Türkçe eklere dayanıklı arama, şikâyet; moderatör ve bölüm moderatörü: sabitle/kilitle/taşı/sil, denetim kaydı). Destek talepleri (benzersiz `TO-yıl-numara`, içerikten tür tespitli ek dosya, durum akışı, iç not, destek masası, yanıt e-postası). Kabul ölçütleri testli. Rapor: [Aşama 13](DevelopmentNotes/Asama-13-Raporu.md) |
| 14 | Yönetim Merkezi | ✅ **Tamamlandı** | Ayrı panel (`/yonetim/`), 62 yetki korumalı uç (her biri için 401/403 testi), pano ve canlı oyun sunucusu metrikleri, oyuncu yönetimi ve yaptırımlar (anında atma), içerik sürümleme (NPC/gemi/mağaza/görev/harita/ayar: taslak, fark, yayın, geri alma, iyimser kilit), iki yetkili onayı, rol atama, şikâyet kuyruğu, bakım modu, duyuru, denetim kaydı. NPC canı/fiyat/görev iki hesapla uçtan uca testli. Rapor: [Aşama 14](DevelopmentNotes/Asama-14-Raporu.md) |
| 15 | Android ve iOS | ⏭ Sıradaki | Capacitor; iOS için macOS + Apple Developer gerekir |
| 16 | Güvenlik ve performans | ⏳ | Yük testi, sızma testi kontrol listesi, yedek tatbikatı |
| 17 | Yayın ve dağıtım | ⏳ | VPS kurulumu, alan adı, TLS, izleme |

## 2. Aşama bazında teslimatlar ve kabul ölçütleri

| # | Ana teslimat | Kabul ölçütleri (özet) |
|---|---|---|
| 5 | Sunucu/şirket seçimi, `players`, profil API + ekranı | Tek hesapta sunucu başına bir pilot; profil web ve mobil görünümde aynı; istatistik alanları istemciden yazılamaz (403 testi) |
| 6 | Hangar, envanter, 2 konfigürasyon, mağazadan başlangıç ekipmanı | Slot uyumsuz takma reddedilir; aynı eşya bir konfigürasyonda iki kez takılamaz; tüm değişiklikler `item_ledger`'da |
| 7 | Phaser istemci, harita yükleme, kamera, mini harita, PC + dokunmatik girdi katmanı | 60 FPS (orta seviye cihaz emülasyonu), HUD tüm yerleşim profillerinde kesilmeden |
| 8 | Oyun sunucusu, bilet, ikili protokol, AOI, tahmin + uzlaştırma + enterpolasyon, yeniden bağlanma, harita geçişi | **İki ayrı hesapla** aynı haritada karşılıklı hareketin görünmesi (otomatik bot istemcileriyle test + manuel iki tarayıcı); 200 ms yapay gecikme ve %5 paket kaybında akıcılık; 100 bot istemciyle yük testi |
| 9 | NPC yapay zekâsı, hasar formülü, ölüm/patlama/ödül, kapılar, boss | Hasar ve ödül yalnızca sunucuda; iki oyuncu aynı NPC'yi vurduğunda ödül katkıya göre bölünür; Yönetim Merkezi'nden can değişikliği canlı NPC'ye yansır |
| 10 | Görev motoru + ~300 görev | Olay tabanlı ilerleme; günlük/haftalık sıfırlama (zaman taklidiyle test); mobilde uzun liste kaydırma |
| 11 | Cüzdan, defter, mağaza, açık artırma, üretim, günlük ödül | Eşzamanlı 50 satın alma isteğinde negatif bakiye yok; aynı `idempotency_key` iki kez uygulanmaz |
| 12 | Klan, diplomasi, grup, arkadaş, engelleme, sohbet kanalları, bildirimler | Grup üyesinin farklı haritadaki konumu izinlere göre görünür; engellenen oyuncunun mesajı iletilmez |
| 13 | Forum (ortak hesap) + destek talepleri | Kilitli konuya yanıt reddedilir; ek dosya türü/boyut sınırı; talep numarası benzersiz |
| 14 | Yönetim Merkezi'nin tüm modülleri | Her uç nokta için yetkisiz → 403 testi; yayınla/geri al; denetim kaydı; iki yetkili onayı |
| 15 | Capacitor Android (APK + AAB) + iOS Xcode projesi | APK gerçek Android cihazda kurulup aynı hesapla PC oyuncusuyla aynı haritada oynanır; iOS derleme talimatı |
| 16 | Güvenlik denetimi, performans optimizasyonu, yedekleme | OWASP ASVS L2 kontrol listesi; 60 dk uzun oturum testi; geri yükleme tatbikatı |
| 17 | Üretim kurulumu | turkorbit.com üzerinde TLS, izleme, alarm, bakım modu |

## 3. Test stratejisi

| Katman | Araç | Kapsam | Aşama 1 durumu |
|---|---|---|---|
| Birim | Vitest | Saf fonksiyonlar (parola politikası, şemalar, seviye/rütbe, eşya/slot kuralları, konfigürasyon istatistikleri, harita giriş koşulları, ayar şeması, ağ protokolü ve ortak hareket simülasyonu, savaş kuralları: hasar, saldırı izni, ödül zarı ve paylaşımı; görev döngüleri, hedef eşleme, tohumlu seçim; açık artırma dönemleri, teklif artışı, günlük seri; sohbet filtresi, klan yetkileri, grup konum izni, diplomasiye göre saldırı), forum ve destek (ek dosya türü tespiti, dosya adı temizliği, talep numarası, metin temizliği), yönetim (alan doğrulama, iç içe ayar yolu, fark, yaptırım/görev şemaları, yetki eşlemesi) | ✅ 95 test |
| Entegrasyon | Vitest + `fastify.inject` + **gerçek PostgreSQL + Redis** + gerçek WebSocket | API uç noktaları, veritabanı kısıtları, tetikleyiciler, eşzamanlı harcama/satın alma, geçitler, oyun sunucusu (bilet, mesaj sırası, hareket, hız hilesi, AOI, tek oturum, kopma, ağ bütçesi), savaş (atış hızı, menzil, ödül ve paylaşımı, kargo, NPC yapay zekâsı, ölüm, PvP, roket, canlı envanter), görevler (zaman taklidiyle sıfırlama, zincir, ödül, eşzamanlı ödül isteği, hangar olayları, oyun sunucusu olayları, anında başarım), ekonomi (üretim, günlük ödül, açık artırma ve eşzamanlı teklif, 50 eşzamanlı satın alma, paketler, madencilik ve ambar), sosyal (klan yetkileri, eşzamanlı katılım sınırı, hazine ve vergi, diplomasi, arkadaş/engel, şikâyet, bildirim, sohbet kanalları ve engelleme, hız sınırı, Redis grubu ve konum izni, diplomasiye göre saldırı), forum ve destek (kilit + eşzamanlı yanıt, moderasyon ve denetim kaydı, bölüm moderatörü, arama, eşzamanlı beğeni, 50 eşzamanlı talep numarası, ek dosya türü/boyut/sayı/süre, indirme yetkisi, durum akışı, iç not, personel yetkileri), odaya girişi tamamlanmamış pilotta periyodik işler (regresyon), Yönetim Merkezi (her yönetim ucu için oturumsuz 401 / oyuncu 403 / yetkisiz personel 403, yaptırımlar ve rütbe kuralı, kalıcı ban ve para verme için iki yetkili onayı + veritabanı CHECK + çıkar çatışması, içerik taslak/yayın/geri alma ve iyimser kilit, mağaza fiyatı ve görev yayını oyuncuya yansır, ayarlar, bakım modu, pano, şikâyet, denetim; gerçek WebSocket ile canlı NPC ölçekleme, askıda anında atma, susturma, duyuru, bakımda atma) | ✅ 214 test |
| API uçtan uca | `scripts/e2e-auth.mjs` (gerçek API + oyun sunucusu süreçleri + gerçek SMTP) | Çoklu hesap, çoklu platform, WebSocket senaryoları, NPC öldürme ve ödül, görev ilerlemesi ve ödülü, günlük ödül, madencilik, üretim, açık artırma, paket, klan, arkadaşlık, WebSocket sohbet, grup konum izni, engelleme ve şikâyet, forum (konu, yanıt, arama, moderatör kilidi), destek (talep, ek dosya, personel yanıtı ve e-postası), Yönetim Merkezi (oyuncuya 403, pano ve oyun sunucusu nabzı, API → Redis → oyun sunucusu süreci → oyuncu bağlantısında canlı NPC canı, askıda gerekçeli anında atma) | ✅ 55/55 adım |
| Arayüz uçtan uca | Playwright (Chromium; 3 masaüstü + iPhone dikey/yatay emülasyonu) | Gerçek tarayıcıda kullanıcı akışları, oyun ekranı, iki pilotun birbirini görmesi, sunucu yeniden başlatma, tek oturum, savaş (hedef, ateş, ödül, kargo, ölüm, yeniden doğma), görevler (izleyici, Q çekmecesi, canlı ilerleme, ödül, görevler sayfası, telefonda kaydırma), ekonomi (madencilik HUD'u, Pazar sekmeleri, satış, üretim, teklif, paket, telefonda Pazar), klan ve sosyal (klan kurma, bildirim zili, arkadaşlık, oyunda sohbet ve özel mesaj, grup paneli ve konum izni, şikâyet, telefonda sohbet ve klan), forum ve destek (misafir okuma, konu/alıntı/beğeni, kilit, arama, talep ve ek, destek masası ve iç not, telefonda forum ve masa), Yönetim Merkezi (yönetici + oyuncu + ikinci yetkili: oyuncuya "Yetkin yok", pano, NPC canı oyunda değişir, fiyat mağazada değişir ve geri alınır, görev yayımlanınca görünür, iki yetkili onayı, askıda anında atma, bakım modu, denetim kaydı, telefonda panel) + ekran görüntüleri | ✅ 84/84 adım |
| Multiplayer | Başsız bot istemcileri (Node) + iki gerçek tarayıcı | Senkronizasyon, gecikme, paket kaybı, yük | Aşama 8 |
| Gerçek cihaz | Android/iOS telefon + tablet | Bkz. [03 §8](03-Platform-Mimarisi.md) | Aşama 15 |
| Güvenlik | Bağımlılık taraması (`npm audit`), statik analiz, sızma testi kontrol listesi | — | `npm audit`: 0 açık |
| Performans | k6 / özel WebSocket yük aracı | API p95 < 150 ms; oyun tik süresi < 10 ms (200 oyunculu harita) | Aşama 8/16 |

## 4. Bağlantı ve performans test ekranı (madde 20 — Aşama 8)
Oyun içinde `Ayarlar → Bağlantı Testi`: sunucu bağlantısı, ping (min/ortalama/maks), gecikme dalgalanması (jitter), FPS, WebSocket durumu, paket kaybı (sıra numarası boşlukları), yeniden bağlanma sayısı, harita senkronizasyonu (sunucu tik farkı), son hata kayıtları. Ham veriler isteğe bağlı olarak destek talebine eklenebilir.
